<?php

$bnWidth = 496;
$bnHeight = 200;

$fbWidth = 496;
$fbHeight = 214;

$uniqueKey = 'MZN9BA7TSVA9UIIAI67A75345A0L12';

$admref_ucp = '../ucp/';

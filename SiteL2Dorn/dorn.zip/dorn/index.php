<?php error_reporting(0); ini_set('error_reporting', 0); ini_set('display_errors', 0); ini_set('display_startup_errors', 0); date_default_timezone_set('America/Sao_Paulo'); ini_set('default_charset', 'UTF-8');


###########################################################
##                   Configurações                       ##
###########################################################

$server_name = 'L2 Dorn -  Old School'; // Nome do servidor
$server_chronicle = 'Interlude'; // Crônica do servidor
$server_url = 'www.Lineage2Boom.com'; // Digite exatamente o URL onde se encontra este site (exemplo: www.l2server.com)


# Contagem regressiva
$cDia = '22'; // Dia
$cMes = '07'; // Mês
$cAno = '2017'; // Ano
$cHor = '16'; // Hora
$cMin = '00'; // Minuto
$cGMT = '-3'; // GMT/UTC
$sumH = 0; // Caso a hora esteja sendo exibida incorretamente, acrescente ou diminua o valor aqui (ex: caso precise diminuir 2 hrs, insira "-2", caso precise acrescentar 3, insira "3" (sem +)


# Download link
$downloadLink = '#'; // Link para download do patch


# Register link
$registerLink = '#'; // Link da página de registro


# Visitors
$visitorsOn = 1; // Exibir visitors? (1 = Sim | 0 = Não)
$visitorsCode = '<a href="http://s11.flagcounter.com/more/k2s"><img src="//s11.flagcounter.com/count2/k2s/bg_D1D1D1/txt_000000/border_D1D1D1/columns_4/maxflags_20/viewers_0/labels_0/pageviews_1/flags_0/percent_0/" alt="Flag Counter" border="0"></a>'; // Code visitors (o código que nós da Atualstudio geramos já é exclusivo para você, mas caso queira gerar um novo, visite: flagcounter.com)

# Página no facebook
$facePopupOn = 1; // Exibir popup do Facebook? (1 = Sim | 0 = Não)
$fbPopupDelay = 1; // De quantos em quantos dias o popup deve aparecer novamente? Ex: Se setar 1 ele aparecerá todo dia
$faceBoxOn = 1; // Exibir box do Facebook na página inicial? (1 = Sim | 0 = Não)
$facePage = 'https://www.facebook.com/L2Dorn/'; // Página no Facebook

# Server info (HTML) - Escreva abaixo as informações do seu servidor
$infoHTML = <<<HTML

<!-- --------- INICIO DO HTML COM INFORMACOES --------- -->


<br />
<div>
	<div>
			<h1>Informations</h1>
Lineage 2 Dorn is a fully dedicated server for its<br> infrastructure in Europe.<br>
Thus, the server has the opportunity to be located in a strategic<br> position within the virtual world. Dorn is based on the old<br> lineage 2 server. We wish you the best gameplay<br> possible to enjoy as much as possible.<br>
This server aims to focus on a retail gameplay without the<br> hardcore grinding part of retail or low rates. It allows casual<br> players to have a great experience as well as hardcore ones.<br>
			
	</div>
	<div>
		<h1>Features</h1>
	        Auto learn skills.<br>
            System clan.<br>
            Quest Nobless Retail.<br>
            Sub Class Free.<br>
            Equipments [C] and [B] selling for adena.<br>
            Armor/Jewels [A] selling for adena, required unseal.<br>
            Weapons [A] selling for farm, required empowerment.<br>
            Armor/Jewels [S] selling for farm, required unseal.<br>
            Weapons [S] selling for farm, required empowerment.<br>
            Slot buffs: 22+4 (Divine Book).<br>
            Buffer full in NPC.<br>
	</div>
</div>

<!-- duas colunas -->
<div class='dualDiv'>
	<div>
		<h1>Rates</h1>
		Experience (EXP) 500x<br />
		Skill Points (SP) 500x<br />
		Adena 100x<br />
		Party Exp 2x<br />
		Party Sp 2x<br />
	</div>
	<div>
		<h1>Enchant</h1>
        Safe +3<br />
        Max Weapon: +16<br />
        Max Armor/Jewels: +10<br />
        Enchant Rate: Retail<br />
	</div>
</div>

<br />

	<div>
		<h1>Farm System</h1>
Varka Silenos - Solo Farm.<br />
Blazing Swamp - Party Farm (Chaotic Zone).<br />
All epic boss are level 80 (Chaotic Zones).<br />
Drop changed whith drop [S] Grade and Blesseds Enchants.<br />
	</div>

<!-- --------- FIM DO HTML --------- -->






HTML;
$server_url = trim($server_url); if(substr($server_url, 0, 7) == 'http://') { $server_url = substr($server_url, 7); } if(substr($server_url, 0, 8) == 'https://') { $server_url = substr($server_url, 8); } if(substr($server_url, -1) == '/') { $server_url = substr($server_url, 0, -1); }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--
	
	Desenvolvido pela Atualstudio
	www.atualstudio.com

          ##########
       ################
    ######          ######
   #####              #####
  ####         ....    ####
 ####        ########  ####
 ####       ########## ####
  ####      ########## ####
  #####       ######## ####
   #####        ****** ####
     ######################
         ################
	
	Website Version 4.0
	
-->

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="keywords" content="<?php echo strtolower($server_name); ?>, l2, lineage, lineage2, lineage 2, lainiege, laineage, lainiage, lineage dois, lineage ii, interlude, hellbound, high five, gracia, epilogue, goddess, freya, h5, c4, c5, c3, c2, c1, lineage1, l1, 10x, free fun, diversao gratis, new server, novo servidor, melhor servidor de lineage, melhor"/>
<meta name="description" content="<?php $description = "Lineage 2 ".trim(strtr($server_name, array('LineageII' => '', 'Lineage2' => '', 'Lineage 2' => '', 'L2' => '', 'LII' => '', 'Lineage' => ''))).", the best server of Lineage 2. Join us for free and play!"; echo $description; ?>"/>
<link rel="shortcut icon" href="./imgs-countdown/favicon.ico">
<title><?php echo $server_name.' - '.$server_chronicle; ?></title>
<link rel="image_src" href="http://<?php echo $server_url; ?>/imgs-countdown/image_src.jpg" />
<meta property="og:title" content="<?php echo $server_name.' - '.$server_chronicle; ?>" />
<meta property="og:site_name" content="<?php echo $server_name; ?>" />
<meta property="og:url" content="http://<?php echo $server_url; ?>" />
<meta property="og:description" content="<?php echo $description; ?>" />
<meta property="og:type" content="website" />
<meta property="og:image" content="http://<?php echo $server_url; ?>/imgs-countdown/image_src.jpg" />

<link rel="stylesheet" type="text/css" href="css-countdown/soon.min.css" media="all" />
<link rel="stylesheet" type="text/css" href="css-countdown/global.css?10" media="all" />

<script type="text/javascript" src="js-countdown/jquery-1.12.4.min.js"></script>

</head>
<body>
	
	<?php if($faceBoxOn == 1) {
	echo "
	<div id=\"fb-root\"></div>
	<script>
		(function(d, s, id) {
			var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)) return;
			js = d.createElement(s); js.id = id;
			js.src = \"//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.7&appId=577018195656213\";
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));
	</script>
	";
	}
	?>
	
	<div class='countdown-date'></div>
	
	<div class='relative-area'>
		<div class='countdown'>
			<div class="soon" id="soon-glow" data-layout="group overlap" data-face="slot doctor glow" data-padding="false" data-scale-max="l" data-visual="ring color-light width-thin glow-progress length-70 gap-0 offset-65"></div>
			<script>(function(){ var i=0,soons = document.querySelectorAll('.countdown .soon'),l=soons.length; for(;i<l;i++) { soons[i].setAttribute('data-due','<?php echo date("Y-m-d\TH:i:s", mktime((($cHor+$cGMT)+$sumH), $cMin, 0, $cMes, $cDia, $cAno)); ?>'); soons[i].setAttribute('data-now','<?php echo date("Y-m-d\TH:i:s"); ?>'); } }());</script>
			<script src="js-countdown/soon.min.js" data-auto="false"></script><script>var soons = document.querySelectorAll('.countdown .soon'); for(var i=0;i<soons.length;i++) { Soon.create(soons[i]); }</script>
		</div>
	</div>
	


	<section>
		
		<article><?php echo $infoHTML; ?></article>
		
		<aside>
			
			<?php
			
			echo "
			<div class='box'>
				<div style='display:table; margin: 0 auto;'>
					<a href='".$downloadLink."' class='downButton'></a>
					<a href='".$registerLink."' target='_blank' class='regiButton'></a>
				</div>
			</div>
			";
			
			if($visitorsOn == 1) {
				echo "
				<div class='box'>
					<h1>Visitors</h1>
					<div>
						".$visitorsCode."
					</div>
				</div>
				";
			}
			
			if($faceBoxOn == 1) {
				echo "
				<div class='box'>
					<h1>Follow Us</h1>
					<div class='facebox'>
						<div class='fb-page' data-href='".$facePage."' data-width='320' data-small-header='false' data-adapt-container-width='true' data-hide-cover='false' data-show-facepile='true' data-show-posts='false'><div class='fb-xfbml-parse-ignore'><blockquote cite='".$facePage."'><a href='".$facePage."'></a></blockquote></div></div>
					</div>
				</div>
				";
			}
			
			?>
			
		</aside>
		
	</section>

	<script type='text/javascript'>$(function(){ $('article').css({ 'min-height': ''+$('aside').height()+'px' }); });</script>
	
	<footer>
		&copy <?php echo date('Y').' '.$server_name; ?> - All rights reserved
		<a href='http://www.atualstudio.com' target='_blank' title='Countdown site by Atualstudio'></a>
	</footer>
	
	<!-- Facebook PopUp -->
	<?php
	if($facePopupOn == 1) {
		echo "
		<div id='fanback'><div id='fan-exit'></div><div id='fanbox'><div id='fanclose'></div><iframe src='//www.facebook.com/plugins/likebox.php?href=".$facePage."&amp;width=402&amp;height=255&amp;colorscheme=light&amp;show_faces=true&amp;border_color=%23E2E2E2&amp;stream=false&amp;header=false&amp;appId=577018195656213' scrolling='no' frameborder='0' allowTransparency='true'></iframe></div></div>
		<script src='js-countdown/jquery.cookie.js' type='text/javascript'></script>
		<script type='text/javascript'>
			$(function() { if($.cookie('atualstudioPopup') != 'yes'){ $('#fanback').delay(100).fadeIn('medium'); $('#fanclose, #fan-exit').click(function(){ $('#fanback').stop().fadeOut('medium'); }); } $.cookie('atualstudioPopup', 'yes', { path: '/', expires: ".intval(trim($fbPopupDelay))." }); });
		</script>";
	}
	?>
	
</body>
</html>
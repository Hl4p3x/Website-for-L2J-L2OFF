<?php
$servername = 'L2 Dorn';
$serverurl = 'http://lineage2boom.com';
$serverversion = 'Interlude';
?>